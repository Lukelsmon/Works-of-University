public class ContaPoupanca extends Conta {
    private static final double TAXA_RENDIMENTO = 0.02;
    
    public ContaPoupanca(String numero, String titular, double saldo) {
        super(numero, titular, saldo);
    }
    
    @Override
    public void aplicarTaxa() {
        double rendimento = saldo * TAXA_RENDIMENTO;
        saldo += rendimento;
        System.out.println("Rendimento de R$ " + rendimento + " aplicado na conta " + numero);
    }
    
    @Override
    public String toString() {
        return super.toString() + " (Conta Poupança)";
    }
}