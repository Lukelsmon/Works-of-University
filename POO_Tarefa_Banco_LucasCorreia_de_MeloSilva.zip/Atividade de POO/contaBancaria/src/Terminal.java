import java.util.Scanner;

public class Terminal {
    private static BancoDeDados banco = new BancoDeDados();
    private static Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
        System.out.println("=== BEM-VINDO AO CORE BANKING 4.0 ===");
        exibirMenu();
    }
    
    private static void exibirMenu() {
        int opcao;
        
        do {
            System.out.println("\n=== MENU PRINCIPAL ===");
            System.out.println("1. Criar Nova Conta");
            System.out.println("2. Listar Todas as Contas");
            System.out.println("3. Realizar Transferência");
            System.out.println("4. Aplicar Taxas Mensais");
            System.out.println("5. Depositar");
            System.out.println("6. Sacar");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1:
                    criarConta();
                    break;
                case 2:
                    banco.listarContas();
                    break;
                case 3:
                    menuTransferencias();
                    break;
                case 4:
                    banco.aplicarTaxasTodasContas();
                    break;
                case 5:
                    realizarDeposito();
                    break;
                case 6:
                    realizarSaque();
                    break;
                case 0:
                    System.out.println("Obrigado por usar o Core Banking 4.0!");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 0);
        
        scanner.close();
    }
    
    private static void criarConta() {
        System.out.println("\n=== CRIAR NOVA CONTA ===");
        System.out.print("Número da conta: ");
        String numero = scanner.nextLine();
        
        System.out.print("Nome do titular: ");
        String titular = scanner.nextLine();
        
        System.out.print("Saldo inicial: R$ ");
        double saldo = scanner.nextDouble();
        
        System.out.println("Tipo de conta:");
        System.out.println("1. Conta Corrente");
        System.out.println("2. Conta Poupança");
        System.out.print("Escolha: ");
        int tipo = scanner.nextInt();
        
        Conta novaConta;
        
        switch (tipo) {
            case 1:
                System.out.print("Limite do cheque especial: R$ ");
                double limite = scanner.nextDouble();
                novaConta = new ContaCorrente(numero, titular, saldo, limite);
                break;
            case 2:
                novaConta = new ContaPoupanca(numero, titular, saldo);
                break;
            default:
                System.out.println("Tipo inválido!");
                return;
        }
        
        banco.adicionarConta(novaConta);
    }
    
    private static void menuTransferencias() {
        System.out.println("\n=== TRANSFERÊNCIAS ===");
        System.out.println("1. Transferência Interna");
        System.out.println("2. Transferência Externa (PIX/TED)");
        System.out.print("Escolha: ");
        int opcao = scanner.nextInt();
        scanner.nextLine();
        
        switch (opcao) {
            case 1:
                System.out.print("Conta de origem: ");
                String origem = scanner.nextLine();
                System.out.print("Conta de destino: ");
                String destino = scanner.nextLine();
                System.out.print("Valor: R$ ");
                double valor = scanner.nextDouble();
                banco.transferirInterno(origem, destino, valor);
                break;
            case 2:
                System.out.print("Conta de origem: ");
                origem = scanner.nextLine();
                System.out.print("Valor: R$ ");
                valor = scanner.nextDouble();
                banco.transferirExterno(origem, valor);
                break;
            default:
                System.out.println("Opção inválida!");
        }
    }
    
    private static void realizarDeposito() {
        System.out.print("Número da conta: ");
        String numero = scanner.nextLine();
        System.out.print("Valor do depósito: R$ ");
        double valor = scanner.nextDouble();
        
        Conta conta = banco.buscarConta(numero);
        if (conta != null) {
            conta.depositar(valor);
        } else {
            System.out.println("Conta não encontrada!");
        }
    }
    
    private static void realizarSaque() {
        System.out.print("Número da conta: ");
        String numero = scanner.nextLine();
        System.out.print("Valor do saque: R$ ");
        double valor = scanner.nextDouble();
        
        Conta conta = banco.buscarConta(numero);
        if (conta != null) {
            conta.sacar(valor);
        } else {
            System.out.println("Conta não encontrada!");
        }
    }
}