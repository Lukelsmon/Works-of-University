public class ContaCorrente extends Conta {
    private double limiteChequeEspecial;
    private static final double TAXA_MANUTENCAO = 15.00;
    
    public ContaCorrente(String numero, String titular, double saldo, double limiteChequeEspecial) {
        super(numero, titular, saldo);
        this.limiteChequeEspecial = limiteChequeEspecial;
    }
    
    @Override
    public boolean sacar(double valor) {
        if (valor > 0 && valor <= (saldo + limiteChequeEspecial)) {
            saldo -= valor;
            System.out.println("Saque de R$ " + valor + " realizado com sucesso!");
            if (saldo < 0) {
                System.out.println("Atenção: Você está usando o cheque especial!");
            }
            return true;
        } else {
            System.out.println("Limite insuficiente! Saldo + Limite: R$ " + (saldo + limiteChequeEspecial));
            return false;
        }
    }
    
    @Override
    public void aplicarTaxa() {
        saldo -= TAXA_MANUTENCAO;
        System.out.println("Taxa de manutenção de R$ " + TAXA_MANUTENCAO + " aplicada na conta " + numero);
    }
    
    public double getLimiteChequeEspecial() {
        return limiteChequeEspecial;
    }
    
    @Override
    public String toString() {
        return super.toString() + " | Limite: R$ " + limiteChequeEspecial + " (Conta Corrente)";
    }
}