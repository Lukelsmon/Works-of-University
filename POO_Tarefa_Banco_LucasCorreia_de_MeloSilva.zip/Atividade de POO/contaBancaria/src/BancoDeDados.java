import java.util.ArrayList;
import java.util.List;

public class BancoDeDados {
    private List<Conta> contas;
    
    public BancoDeDados() {
        this.contas = new ArrayList<>();
    }
    
    public void adicionarConta(Conta conta) {
        contas.add(conta);
        System.out.println("Conta " + conta.getNumero() + " criada com sucesso!");
    }
    
    public Conta buscarConta(String numero) {
        for (Conta conta : contas) {
            if (conta.getNumero().equals(numero)) {
                return conta;
            }
        }
        return null;
    }
    
    public void listarContas() {
        if (contas.isEmpty()) {
            System.out.println("Nenhuma conta cadastrada no sistema.");
            return;
        }
        
        System.out.println("\n=== LISTA DE CONTAS ===");
        for (int i = 0; i < contas.size(); i++) {
            System.out.println((i + 1) + ". " + contas.get(i));
        }
    }
    
    public boolean transferirInterno(String contaOrigem, String contaDestino, double valor) {
        Conta origem = buscarConta(contaOrigem);
        Conta destino = buscarConta(contaDestino);
        
        if (origem == null || destino == null) {
            System.out.println("Conta de origem ou destino não encontrada!");
            return false;
        }
        
        if (origem.sacar(valor)) {
            destino.depositar(valor);
            System.out.println("Transferência interna de R$ " + valor + " realizada com sucesso!");
            return true;
        }
        
        return false;
    }
    
    public boolean transferirExterno(String contaOrigem, double valor) {
        Conta origem = buscarConta(contaOrigem);
        
        if (origem == null) {
            System.out.println("Conta de origem não encontrada!");
            return false;
        }
        
        if (origem.sacar(valor)) {
            System.out.println("Transferência externa (PIX/TED) de R$ " + valor + " realizada com sucesso!");
            System.out.println("Dinheiro enviado para conta externa.");
            return true;
        }
        
        return false;
    }
    
    public void aplicarTaxasTodasContas() {
        System.out.println("\n=== APLICANDO TAXAS MENSAS ===");
        for (Conta conta : contas) {
            conta.aplicarTaxa();
        }
    }
    
    public int getTotalContas() {
        return contas.size();
    }
}